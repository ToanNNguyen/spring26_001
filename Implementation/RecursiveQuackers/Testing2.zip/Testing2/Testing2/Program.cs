﻿ namespace Testing2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter First Number: ");
            int userInput1 = int.Parse(Console.ReadLine());

            Console.Write("Enter Second Number: ");
            int userInput2 = int.Parse(Console.ReadLine());

            int finalResult = RecursiveAddition(userInput1, userInput2);
            Console.WriteLine(finalResult);
        }

        public static int RecursiveAddition(int firstNum, int secondNum) 
        {
            

            int sum = firstNum + secondNum;

            if (sum >= 1 && sum <= 9)
            {

            }
            else 
            {
				List<int> digits = sum.ToString().Select(c => (int)char.GetNumericValue(c)).ToList();

				int[] holdNumber = new int[1];



				for (int i = 0; i < digits.Count; i++)
				{
					if (i == digits.Count - 1)
					{
						holdNumber[0] = digits[i];
					}

				}

                int lastDigit = holdNumber[0];

                digits.RemoveAt(digits.Count - 1);

				int result = int.Parse(string.Concat(digits));


                return RecursiveAddition(result, lastDigit);


			}


            return sum;

           


			
		    

		}
	}
}
